#' Ensures `shoe` is registered as a global variable
#'
#' @name global shoe
utils::globalVariables("shoe")
